<?php
return [
  'host' => "http://map.makrab.net",
  'port' => "18080",
  'user' => "Администратор",
  'password' => "Kvesta21",
  'schema' => 'test_uat_1'
];
