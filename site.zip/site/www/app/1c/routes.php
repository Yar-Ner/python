<?php
return [
  'BITRIX_HOTS_DISTANCE' => '/hs/makrab/routes/routedata',
  'BITRIX_HOTS_TASKS_STATUS' => '/hs/makrab/tasks/status',
  'BITRIX_HOTS_TASKS_ORDERS_STATUS' => '/hs/makrab/tasks/orders/status',
  'BITRIX_HOTS_ODOMETER_VALUE' => '/hs/makrab/tasks/odometr',
  'BITRIX_HOTS_TASKS_WEIGHT' => '/hs/makrab/tasks/weightCard',
];
