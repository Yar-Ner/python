<?php
return [
    'db_host' => "192.168.137.227",
    'db_user' => "erpico",
    'db_port' => "3306",
    'db_password' => "testing",
    'db_schema'=> "makrab",
];
