export function getCities(){
	return cities;
}

const cities = [
	{ id:"$empty", value:"-- Not selected --", $empty:true },
	{ id:"1", value:"Tirane, Albania" },
	{ id:"2", value:"Buenos Aires, Argentina" },
	{ id:"3", value:"Canberra, Australia" },
	{ id:"4", value:"Vienna, Austria" },
	{ id:"5", value:"Minsk, Belarus" },
	{ id:"6", value:"Brussels, Belgium" },
	{ id:"7", value:"Brasilia, Brazil" },
	{ id:"8", value:"Ottawa, Canada" },
	{ id:"9", value:"Beijing, China" },
	{ id:"10", value:"Prague, Czech Republic" },
	{ id:"11", value:"Copenhagen, Denmark" },
	{ id:"12", value:"Cairo, Egypt" },
	{ id:"13", value:"Helsinki, Finland" },
	{ id:"14", value:"Paris, France" },
	{ id:"15", value:"Tbilisi, Georgia" },
	{ id:"16", value:"Berlin, Germany" },
	{ id:"17", value:"New Delhi, India" },
	{ id:"18", value:"Dublin, Ireland" },
	{ id:"19", value:"Rome, Italy" },
	{ id:"20", value:"Tokyo, Japan" },
	{ id:"21", value:"Wellington, New Zealand" },
	{ id:"22", value:"Seoul, Republic of Korea" },
	{ id:"23", value:"Madrid, Spain" },
	{ id:"24", value:"Stockholm, Sweden" },
	{ id:"25", value:"Washington, United States" }
];
