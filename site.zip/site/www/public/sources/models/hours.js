const data = [
	{"id":1,"activity":"Tasks","hours":48,"color":"#8664C6"},
	{"id":2,"activity":"Meeting","hours":24,"color":"#1CA1C1"},
	{"id":4,"activity":"Calls","hours":19,"color":"#FDBF4C"},
	{"id":3,"activity":"Mail","hours":12,"color":"#F8643F"}
];

export function getHours(){
	return data;
}