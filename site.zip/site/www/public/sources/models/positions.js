export function getPositions(){
	return positions;
}

const positions = [
	{ id:"$empty", value:"-- Not selected --", $empty:true },
	{ id:"1", value:"Chief Scientific Officer", color:"#8664C6" },
	{ id:"2", value:"Chief Technology Officer", color:"#1CA1C1" },
	{ id:"3", value:"Chief Executive Officer", color:"#F8643F" }
];
