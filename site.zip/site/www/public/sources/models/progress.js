const data = [{"id":1,"week":1,"tasks":29},{"id":2,"week":3,"tasks":45},{"id":3,"week":7,"tasks":56},{"id":4,"week":9,"tasks":56},{"id":5,"week":11,"tasks":62},{"id":6,"week":14,"tasks":86},{"id":7,"week":18,"tasks":73},{"id":8,"week":22,"tasks":58},{"id":9,"week":28,"tasks":50},{"id":10,"week":31,"tasks":25},{"id":11,"week":35,"tasks":68},{"id":12,"week":39,"tasks":95},{"id":13,"week":45,"tasks":87},{"id":14,"week":47,"tasks":58},{"id":15,"week":49,"tasks":70},{"id":16,"week":52,"tasks":80}];

export function getProgress(){
	return data;
}