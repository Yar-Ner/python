export function getProjects(){
	return projects;
}

const projects = [
	{ tasks17:"54", tasks18:"78", project:"80" },
	{ tasks18:"54", tasks17:"34", project:"70" },
	{ tasks17:"84", tasks18:"50", project:"60" },
	{ tasks17:"47", tasks18:"73", project:"50" },
	{ tasks17:"64", tasks18:"53", project:"40" },
	{ tasks17:"45", tasks18:"73", project:"30" },
];