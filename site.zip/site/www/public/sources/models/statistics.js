export function getStats(){
	return stats;
}

const stats = [
	{"week":1,"tasks18":25},
	{"week":2,"tasks17":20},
	{"week":4,"tasks18":50},
	{"week":6,"tasks17":25},
	{"week":8,"tasks18":38},
	{"week":10,"tasks17":8},
	{"week":10,"tasks18":40},
	{"week":13,"tasks18":58},
	{"week":15,"tasks17":40},
	{"week":17,"tasks18":59},
	{"week":19,"tasks18":79},
	{"week":20,"tasks17":22},
	{"week":24,"tasks18":25},
	{"week":28,"tasks17":85},
	{"week":31,"tasks18":57},
	{"week":36,"tasks17":68},
	{"week":36,"tasks18":95},
	{"week":40,"tasks17":84},
	{"week":42,"tasks18":33},
	{"week":44,"tasks17":73},
	{"week":46,"tasks18":51},
	{"week":47,"tasks18":29},
	{"week":52,"tasks17":98},
	{"week":52,"tasks18":79}
];
