export function getStats(){
	return data;
}

const data = [
	{ id:"1", value:"Manufacturing", number:294, type:"all" },
	{ id:"2", value:"Wholesale stores", number:335, type:"first" },
	{ id:"3", value:"Retail stores", number:422, type:"second" }
];
