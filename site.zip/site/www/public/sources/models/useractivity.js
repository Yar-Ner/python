export function getUserActivity(){
	return users;
}

const users = [
	{ id:"7", country:"Brazil", users:70 },
	{ id:"8", country:"Canada", users:80 },
	{ id:"9", country:"China", users:90 }
];
