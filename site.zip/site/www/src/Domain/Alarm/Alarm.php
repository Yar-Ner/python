<?php

declare(strict_types=1);


namespace App\Domain\Alarm;


class Alarm
{
    /**
     * @var int|null
     */
    private $id;

    /**
     * @var string
     */
    public $type;

    /**
     * @var string
     */
    public $icon;

    /**
     * @var string
     */
    public $name;

    /**
     * @var string
     */
    public $color;

    /**
     * @var int
     */
    public $deleted;

    public function __construct(?int $id, string $type, string $icon, string $name, string $color, int $deleted = 0)
    {
        $this->id = $id;
        $this->type = $type;
        $this->icon = $icon;
        $this->name = $name;
        $this->color = $color;
        $this->deleted = $deleted;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function isDeleted(): int
    {
        return $this->deleted;
    }

    public function getColor(): string
    {
        return $this->color;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getIcon(): string
    {
        return $this->icon;
    }

    public function getType(): string
    {
        return $this->type;
    }
}
