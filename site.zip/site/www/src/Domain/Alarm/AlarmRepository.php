<?php

declare(strict_types=1);


namespace App\Domain\Alarm;

use App\Domain\Alarm\Request\CreateVehicleAlarmRequest;

interface AlarmRepository
{
    /**
     * @return Alarm[]
     */
    public function findAll(): array;

    public function findAllAlarmsVehicles(int $id): array;

    public function getById(int $id): Alarm;

    public function createVehicleAlarm(CreateVehicleAlarmRequest $request): int;

    public function changeActiveVehicleAlarmAction(int $id): int;
}

