<?php
declare(strict_types=1);

namespace App\Domain\Alarm\Request;

class CreateVehicleAlarmRequest
{
    public $vehicleId ;
    public $alarmId;
    public $locationId;
    public $photoId;
    public $comment;

    public static function createFromArray(array $data): CreateVehicleAlarmRequest
    {
        $obj = new self();

        $obj->vehicleId = $data['vehicle_id'];
        $obj->alarmId = $data['alarm_id'];
        $obj->locationId = $data['location_id'];
        $obj->photoId = $data['photo_id'] ?? null;
        $obj->comment = $data['comment'] ?? null;

        return $obj;
    }
}
