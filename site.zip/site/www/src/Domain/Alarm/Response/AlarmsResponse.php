<?php

declare(strict_types=1);

namespace App\Domain\Alarm\Response;


use App\Domain\Alarm\Alarm;

class AlarmsResponse implements \JsonSerializable
{
    /**
     * @var Alarm[]
     */
    private $alarms;

    public function __construct(array $alarms)
    {
        $this->alarms = $alarms;
    }

    public function jsonSerialize(): array
    {
        return array_map(static function(Alarm $alarm) {
            return [
                'id' => $alarm->getId(),
                'type' => $alarm->getType(),
                'icon' => $alarm->getIcon(),
                'name' => $alarm->getName(),
            ];
        }, $this->alarms);
    }
}