<?php

declare(strict_types=1);

namespace App\Domain\Alarm\Response;


use App\Domain\Alarm\VehicleAlarm;

class VehicleAlarmsResponse implements \JsonSerializable
{
  /**
   * @var VehicleAlarm[]
   */
  private $vehicleAlarms;

  public function __construct(array $vehicleAlarms)
  {
    $this->vehicleAlarms = $vehicleAlarms;
  }

  public function jsonSerialize(): array
  {
    return array_map(static function(VehicleAlarm $vehicleAlarm) {
      return [
        'id' => $vehicleAlarm->getId(),
        'vehicles_id' => $vehicleAlarm->getVehiclesId(),
        'created' => $vehicleAlarm->getCreated(),
        'active' => $vehicleAlarm->getActive(),
        'alarm_id' => $vehicleAlarm->getAlarmId(),
        'alarm_text' => $vehicleAlarm->getAlarmText(),
        'decision_time' => $vehicleAlarm->getDecisionTime(),
        'reset_time' => $vehicleAlarm->getResetTime(),
        'tasks_id' => $vehicleAlarm->getTasksId(),
        'push_sent' => $vehicleAlarm->getPushSent(),
        'location_id' => $vehicleAlarm->getLocationId(),
        'photos_id' => $vehicleAlarm->getPhotosId(),
        'alarm_type' => $vehicleAlarm->getAlarmType(),
        'alarm_icon' => $vehicleAlarm->getAlarmIcon(),
        'alarm_name' => $vehicleAlarm->getAlarmName(),
        'alarm_color' => $vehicleAlarm->getAlarmColor(),
        'vehicle_number' => $vehicleAlarm->getNumber(),
        'fullname' => $vehicleAlarm->getFullname()
      ];
    }, $this->vehicleAlarms);
  }
}