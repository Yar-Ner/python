<?php

declare(strict_types=1);


namespace App\Domain\Alarm;


class VehicleAlarm
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var int
     */
    private $vehicles_id;

    /**
     * @var string
     */
    private $created;

    /**
     * @var int
     */
    private $active;

    /**
     * @var int
     */
    private $alarm_id;

    /**
     * @var string
     */
    private $alarm_text;

    /**
     * @var int
     */
    private $decision_time;

    /**
     * @var string
     */
    private $reset_time;

    /**
     * @var int
     */
    private $tasks_id;

    /**
     * @var string
     */
    private $push_sent;

    /**
     * @var int
     */
    private $location_id;

    /**
     * @var int
     */
    private $photos_id;

    /**
     * @var string
     */
    private $alarmType;

    /**
     * @var string
     */
    private $alarmIcon;

    /**
     * @var string
     */
    private $alarmName;

    /**
     * @var string
     */
    private $alarmColor;

    /**
     * @var string
     */
    private $number;

    /**
     * @var string
     */
    private $fullname;


    public function __construct(
      int $id,
      int $vehicles_id,
      string $created,
      int $active,
      int $alarm_id,
      ?string $alarm_text,
      ?int $decision_time,
      ?string $reset_time,
      ?int $tasks_id,
      ?string $push_sent,
      int $location_id,
      ?int $photos_id,
      string $type,
      string $icon,
      string $name,
      string $color,
      string $number
//      ?string $fullname
    )
    {
        $this->id = $id;
        $this->vehicles_id = $vehicles_id;
        $this->created = $created;
        $this->active = $active;
        $this->alarm_id = $alarm_id;
        $this->alarm_text = $alarm_text;
        $this->decision_time = $decision_time;
        $this->reset_time = $reset_time;
        $this->tasks_id = $tasks_id;
        $this->push_sent = $push_sent;
        $this->location_id = $location_id;
        $this->photos_id = $photos_id;
        $this->alarmType = $type;
        $this->alarmIcon = $icon;
        $this->alarmName = $name;
        $this->alarmColor = $color;
        $this->number = $number;
//        $this->fullname = $fullname;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getVehiclesId(): ?int
    {
      return $this->vehicles_id;
    }

    public function getCreated(): ?string
    {
      return $this->created;
    }

    public function getActive(): ?int
    {
      return $this->active;
    }

    public function getAlarmId(): ?int
    {
      return $this->alarm_id;
    }

    public function getDecisionTime(): ?int
    {
      return $this->decision_time;
    }

    public function getAlarmText(): ?string
    {
      return $this->alarm_text;
    }

    public function getResetTime(): ?string
    {
      return $this->reset_time;
    }

    public function getTasksId(): ?int
    {
      return $this->tasks_id;
    }

    public function getPushSent(): ?string
    {
      return $this->push_sent;
    }

    public function getLocationId(): ?int
    {
      return $this->location_id;
    }

    public function getPhotosId(): ?int
    {
      return $this->photos_id;
    }

    public function getAlarmType(): string
    {
      return $this->alarmType;
    }

    public function getAlarmName(): string
    {
      return $this->alarmName;
    }

    public function getAlarmIcon(): string
    {
      return $this->alarmIcon;
    }

    public function getAlarmColor(): string
    {
      return $this->alarmColor;
    }

    public function getNumber(): string
    {
      return $this->number;
    }

    public function getFullname(): ?string
    {
      return $this->fullname;
    }
}
