<?php


namespace App\Domain\Chat;


class ChatMessage implements \JsonSerializable
{
    private $id;
    private $senderId;
    private $recipientId;
    private $isRead;
    private $content;
    private $type;
    private $name;
    private $size;
    private $hash;

    /**
     * @var \DateTimeImmutable
     */
    private $cratedAt;

    public function __construct(
        ?int $id,
        int $senderId,
        int $recipientId,
        int $isRead,
        string $content,
        \DateTimeImmutable $cratedAt,
        ?int $type = null,
        ?string $name = null,
        ?string $size = null,
        ?string $hash = null
    ) {
        $this->id = $id;
        $this->senderId = $senderId;
        $this->recipientId = $recipientId;
        $this->isRead = $isRead;
        $this->content = $content;
        $this->cratedAt = $cratedAt;
        $this->type = $type;
        $this->name = $name;
        $this->size = $size;
        $this->hash = $hash;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSenderId(): int
    {
        return $this->senderId;
    }

    public function getRecipientId(): int
    {
        return $this->recipientId;
    }

    public function isRead(): int
    {
        return $this->isRead;
    }

    public function getContent(): string
    {
        return $this->content;
    }

    public function getType(): ?int
    {
        return $this->type;
    }

    public function getName(): ?string
    {
        return $this->type;
    }

    public function getSize(): ?string
    {
        return $this->type;
    }

    public function getHash(): ?string
    {
        return $this->hash;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function jsonSerialize(): array
    {
        $return = [
            'id' => $this->id,
            'text' => $this->content,
            'user_id' => $this->senderId,
            'chat_id' => $this->recipientId,
            'date' => $this->cratedAt->format('Y-m-d H:i:s'),
            'type' => $this->type
        ];
        if ($this->type === 800 && !$this->name) {
            $return['type'] = null;
        }
        if ($this->type === 800 && $this->name) {
            $return['text'] = $_SERVER['HTTP_REFERER'] . "files/$this->hash\n$this->name\n$this->size\n" . $_SERVER['HTTP_REFERER'] . "files/$this->hash";
        }

        return $return;
    }
}