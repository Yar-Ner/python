<?php


namespace App\Domain\Chat\Request;


class CreateChatMessageRequest
{

    public $content;

    public $recipientId;
}