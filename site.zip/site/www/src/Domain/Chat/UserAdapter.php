<?php


namespace App\Domain\Chat;


use App\Domain\User\User;

class UserAdapter
{
    public static function toChatFormat(User $user, ?int $currentUserId = null, int $unreadCount = 0, $lastMessage = null): array
    {
        $return = [
          'id' => $user->getId(),
          'name' => $user->getFullname(),
          'email' => $user->getUsername(),
          'users' => [$user->getId(), $currentUserId],
          'unread_count' => $unreadCount,
        ];

        if (isset($lastMessage['content'])) {
            if (isset($lastMessage['type']) && isset($lastMessage['name']) && $lastMessage['type'] === 800) {
                $return['message'] = $lastMessage['name'];
            } else {
                $return['message'] = $lastMessage['content'];
            }
        }
        if (isset($lastMessage['created_at'])) $return['date'] = $lastMessage['created_at'];

        return $return;
    }
}