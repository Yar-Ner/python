<?php
declare(strict_types=1);

namespace App\Domain\Contractor;

use App\Domain\Contractor\Request\CreateContractorRequest;
use App\Domain\Contractor\Request\UpdateContractorRequest;
use App\Domain\Task\TaskAddress\TaskAddress;
use JsonSerializable;

class Contractor implements JsonSerializable
{
    /** @var int|null*/
    private $id;

    /** @var string*/
    public $ext_id;

    /** @var string*/
    public $name;

    /** @var string*/
    public $code;

    /** @var string*/
    public $inn;

    /** @var string*/
    public $comment;

    /** @var array*/
    public $addresses;

    /** @var int|null*/
    public $deleted;

    public function __construct(
        ?int $id,
        string $ext_id,
        ?string $name,
        ?string $code,
        ?string $inn,
        ?string $comment,
        ?array $addresses,
        ?int $deleted
    ) {
        $this->id = $id;
        $this->ext_id = $ext_id;
        $this->name = $name;
        $this->code = $code;
        $this->inn = $inn;
        $this->comment = $comment;
        $this->addresses = $addresses;
        $this->deleted = $deleted;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getExtId(): string
    {
        return $this->ext_id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function jsonSerialize(): array
    {
        $return = [
            'id' => $this->id,
            'ext_id' => $this->ext_id,
            'inn' => $this->inn,
            'addresses' => $this->addresses,
            'deleted' => $this->deleted
        ];

        if ($this->name) $return['name'] = $this->name;
        if ($this->code) $return['code'] = $this->code;
        if ($this->comment) $return['comment'] = $this->comment;

        return $return;
    }

    public function getCode(): ?string
    {
        return $this->code;
    }

    public function getInn(): string
    {
        return $this->inn;
    }

    public function getComment(): ?string
    {
        return $this->comment;
    }

    public function getAddresses(): ?array
    {
      return $this->addresses;
    }

    public function getDeleted(): ?int
    {
        return $this->deleted;
    }

    public static function createFromRequest(CreateContractorRequest $request): Contractor
    {
        return new Contractor(
            null,
            $request->ext_id,
            $request->name,
            $request->code,
            $request->inn,
            $request->comment,
            $request->geoobjectsId,
            $request->deleted
        );
    }

    public function UpdateFromRequest(UpdateContractorRequest $request): void
    {
        if ($request->ext_id) $this->ext_id = $request->ext_id;
        if ($request->name) $this->name = $request->name;
        if ($request->code) $this->code = $request->code;
        if ($request->inn) $this->inn = $request->inn;
        if ($request->comment) $this->comment = $request->comment;
        $this->addresses = $request->geoobjectsId ?? $this->addresses;
        if ($request->deleted) $this->deleted = $request->deleted;
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }
}
