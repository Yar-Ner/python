<?php
declare(strict_types=1);

namespace App\Domain\Contractor;

use App\Domain\DomainException\DomainRecordNotFoundException;

class ContractorNotFoundException extends DomainRecordNotFoundException
{
    public $message = 'The contractor you requested does not exist.';
}
