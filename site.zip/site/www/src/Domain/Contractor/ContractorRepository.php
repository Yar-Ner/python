<?php
declare(strict_types=1);

namespace App\Domain\Contractor;

interface ContractorRepository
{
    /**
     * @return Contractor[]
     */
    public function findAll(int $pos, int $count, ?int $onlyCount, array $filters);

    public function delete(int $id);

    /**
     * @throws ContractorNotFoundException
     */
    public function getById(int $id): Contractor;

    public function check1cContractor(string $ext_id): ?Contractor;

    public function createOrUpdateByExtId(Contractor $contractor): int;

    public function save(Contractor $contractor): int;

}
