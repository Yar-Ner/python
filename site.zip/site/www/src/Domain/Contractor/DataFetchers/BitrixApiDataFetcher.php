<?php

declare(strict_types=1);

namespace App\Domain\Contractor\DataFetchers;


use App\Domain\Contractor\Request\FetchContractorRequest;
use App\Domain\Contractor\Request\FetchContractorsRequest;
use App\Domain\SharedContext\BrowserDriver\BrowserSessionFactory;
use App\Domain\SharedContext\BrowserDriver\Request;
use App\Domain\SharedContext\BrowserDriver\Response;
use Fig\Http\Message\RequestMethodInterface;
use Fig\Http\Message\StatusCodeInterface;
use Symfony\Component\PropertyInfo\Extractor\PhpDocExtractor;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ArrayDenormalizer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

class BitrixApiDataFetcher implements DataFetcher
{

    //todo: Use env for store this secrets.
    private const BITRIX_HOTS = 'http://185.10.129.195:18080/test_uat_1/hs/makrab/contractors';
    private const BITRIX_AUTH_TYPE = CURLAUTH_BASIC;
    private const BITRIX_USER = 'Администратор';
    private const BITRIX_SECRET = 'Kvesta21';

    /**
     * @var BrowserSessionFactory
     */
    private $browserSessionFactory;

    public function __construct(BrowserSessionFactory $browserSessionFactory)
    {
        $this->browserSessionFactory = $browserSessionFactory;
    }


    public function fetchNewContractors(): FetchContractorsRequest
    {
        $browserSession = $this->browserSessionFactory->createCurlBrowserSession();
        $response = $browserSession->request(
            Request::make(
                RequestMethodInterface::METHOD_GET,
                self::BITRIX_HOTS,
                [],
                [],
                [
                    CURLOPT_HTTPAUTH => self::BITRIX_AUTH_TYPE,
                    CURLOPT_USERPWD => sprintf('%s:%s', self::BITRIX_USER, self::BITRIX_SECRET),
                ]
            )
        );

        if ($response->status !== StatusCodeInterface::STATUS_OK) {
            throw new \Exception(sprintf('Wrong status code %d from request %s', $response->status, $response->url));
        }

        return $this->serializeResponse($response);

    }

    private function serializeResponse(Response $response): FetchContractorsRequest
    {
        $serializer = new Serializer(
            [new ObjectNormalizer(null, null, null, new PhpDocExtractor()), new ArrayDenormalizer()],
            [new JsonEncoder()]
        );

        $fetchContractors = new FetchContractorsRequest();
        $fetchContractors->contractors = $serializer->deserialize(
            $response->content,
            sprintf('%s[]',FetchContractorRequest::class),
            JsonEncoder::FORMAT
        );

        return $fetchContractors;
    }
}
