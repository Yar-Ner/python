<?php

declare(strict_types=1);


namespace App\Domain\Contractor\DataFetchers;


use App\Domain\Contractor\Request\FetchContractorsRequest;

interface DataFetcher
{

    public function fetchNewContractors(): FetchContractorsRequest;

}
