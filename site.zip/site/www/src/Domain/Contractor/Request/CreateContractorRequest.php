<?php
declare(strict_types=1);

namespace App\Domain\Contractor\Request;

class CreateContractorRequest
{
    /** @var string*/
    public $ext_id;

    /** @var string*/
    public $name;

    /** @var string*/
    public $code;

    /** @var string*/
    public $inn;

    /** @var string*/
    public $comment;

    /** @var array*/
    public $geoobjectsId;

    /** @var int|null*/
    public $deleted;

    public static function createFromArray(array $data): CreateContractorRequest
    {
        $obj = new self();

        $obj->ext_id = $data['ext_id'];
        $obj->name = $data['name'];
        $obj->code = $data['code'] ?? null;
        $obj->inn = $data['inn'];
        $obj->comment = $data['comment'] ?? null;
        $obj->geoobjectsId = isset($data['geoobjectsId']) && $data['geoobjectsId'] !== '' ? explode(',', $data['geoobjectsId']) : [];
        $obj->deleted = 0;

        return $obj;
    }
}
