<?php

declare(strict_types=1);


namespace App\Domain\Contractor\Request;


class FetchContractorRequest
{

    public $id;
    public $name;
    public $inn;
    public $comment;

}
