<?php

declare(strict_types=1);


namespace App\Domain\Contractor\Request;


class FetchContractorsRequest
{
    /** @var FetchContractorRequest[] */
    public $contractors;

    public function iterate(): \Generator
    {
        foreach ($this->contractors as $contractor) {
            yield $contractor;
        }
    }

}
