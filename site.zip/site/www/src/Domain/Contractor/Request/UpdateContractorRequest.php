<?php
declare(strict_types=1);

namespace App\Domain\Contractor\Request;

class UpdateContractorRequest
{
    /** @var string*/
    public $ext_id;

    /** @var string*/
    public $name;

    /** @var string*/
    public $code;

    /** @var string*/
    public $inn;

    /** @var string*/
    public $comment;

    /** @var array*/
    public $geoobjectsId;

    /** @var int|null*/
    public $deleted;

    public static function createFromArray(array $data): UpdateContractorRequest
    {
        $obj = new self();

        if (isset($data['ext_id'])) $obj->ext_id = $data['ext_id'];
        if (isset($data['name'])) $obj->name = $data['name'];
        if (isset($data['code'])) $obj->code = $data['code'];
        if (isset($data['inn'])) $obj->inn = $data['inn'];
        if (isset($data['comment'])) $obj->comment = $data['comment'];
        $obj->geoobjectsId = isset($data['geoobjectsId']) && $data['geoobjectsId'] !== '' ? explode(',', $data['geoobjectsId']) : [];
        $obj->deleted = $data['deleted'] ?? 0;

        return $obj;
    }
}
