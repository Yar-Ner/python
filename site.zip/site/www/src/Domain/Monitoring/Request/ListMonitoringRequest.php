<?php

declare(strict_types=1);

namespace App\Domain\Monitoring\Request;


class ListMonitoringRequest
{
  public $vehiclesId;
}
