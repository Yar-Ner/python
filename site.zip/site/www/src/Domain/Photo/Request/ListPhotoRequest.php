<?php

declare(strict_types=1);

namespace App\Domain\Photo\Request;


class ListPhotoRequest
{
    public $ordersId;

    public $alarmsId;

    public $vehiclesId;
}
