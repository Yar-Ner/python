<?php


namespace App\Domain\Task\Request\Modify;


class AddressContractorRequest
{
    public $id;
    public $ext_id;
    public $name;
    public $code;
}
