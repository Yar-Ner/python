<?php


namespace App\Domain\Task\Request;


class PayloadRequest
{
  public $orderId;
  public $hopper;
  public $replacementHopper;
}