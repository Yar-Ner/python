<?php


namespace App\Domain\Task\Request;


class StatusRequest
{
    public $orderId;
    public $locationId;
}
