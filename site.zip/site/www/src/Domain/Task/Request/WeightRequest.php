<?php


namespace App\Domain\Task\Request;


class WeightRequest
{
  public $loadedWeight;
  public $emptyWeight;
}