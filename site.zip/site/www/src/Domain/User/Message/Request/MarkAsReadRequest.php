<?php

declare(strict_types=1);

namespace App\Domain\User\Message\Request;

class MarkAsReadRequest
{
    /**
     * @var int[]
     */
    public $id;

}
